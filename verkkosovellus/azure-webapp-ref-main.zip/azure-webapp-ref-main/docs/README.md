# Topics
- [OIDC for Github](./docs/OIDC.md)
- Frontend/Backend authentication
- Frontend concept
- Backend concept
- Worker-app concept
- Private links
- Pipelines
